# python-banking-project-with-mysql-database-and-using-tkinter
python banking project with tkinter and mysql database connection
#step by step guide to run the complete project
# install database mysql
here is link on installation
https://www.sqlshack.com/how-to-install-mysql-database-server-8-0-19-on-windows-10/
after installation
open mysql by providing your userid and password like in code there is my userid and password
# now create database by running query
Create DB so
# now make all the table emp3
+---------+-------------+------+-----+---------+-------+
| Field   | Type        | Null | Key | Default | Extra |
+---------+-------------+------+-----+---------+-------+
| name    | varchar(20) | YES  |     | NULL    |       |
| amount  | int(11)     | YES  |     | NULL    |       |
| account | int(11)     | YES  |     | NULL    |       |
| ifsc    | int(11)     | YES  |     | NULL    |       |
+---------+-------------+------+-----+---------+-------+
now afte this everything will be run easily if still you have doubt please ask me query i will help
